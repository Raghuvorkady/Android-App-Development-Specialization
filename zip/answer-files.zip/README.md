AAD(Android App Development) Basics is an Android Project which helps students to learn about the important concepts in Android i.e Activity, BroadcastReceiver, Services, ContentProvider and download images.
	In the app, there are Bottom tabs, which helps to us learn each concepts with examples. And a hamgerbuger menu to switch between ImageDownloader Activity and the bottom tab Activity.

In the bottom tab Activity, there are four tabs,
i) Activity
ii) BroadcastReceiver
iii) Services
iv) ContentProvider

And in the ImageDownloader Activity(web service), there is one search bar, where user needs to enter the URL address of an image, so that he/she can download it.
Using network protocols the app, finds the uploaded image from various web servers and makes it possible to view and download the image for the user.

URL: https://www.freedigitalphotos.net/images/img/homepage/87357.jpg
